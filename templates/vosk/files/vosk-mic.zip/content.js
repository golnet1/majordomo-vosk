var iframe = document.createElement('iframe');
iframe.id = 'vosk-mic-proxy';
iframe.src = chrome.runtime.getURL('proxy.html');
iframe.style.display = 'none';
document.body.appendChild(iframe);

function inject(code) {
  var s = document.createElement('script');
  s.textContent = code;
  (document.head || document.documentElement).appendChild(s);
}

inject('window.__voskMicReady = false;');

iframe.onload = function() {
  inject('window.__voskMicReady = true;');
};

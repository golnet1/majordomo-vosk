var context = null, stream = null, scriptNode = null;
var listening = false, speaking = false, chunks = [];
var silenceFrames = 0, speechFrames = 0;

var VAD_THRESHOLD = 0.02;
var SILENCE_MAX = 30;
var SPEECH_MIN = 5;
var FRAME_SIZE = 2048;

var sampleRate = 16000;

function sendToParent(msg) {
  parent.postMessage(msg, '*');
}

function startCapture() {
  navigator.mediaDevices.getUserMedia({ audio: true }).then(function(s) {
    stream = s;
    context = new (window.AudioContext || window.webkitAudioContext)();
    sampleRate = context.sampleRate;
    var source = context.createMediaStreamSource(stream);

    scriptNode = context.createScriptProcessor(FRAME_SIZE, 1, 1);
    source.connect(scriptNode);
    scriptNode.connect(context.destination);

    listening = true;
    speaking = false;
    chunks = [];
    silenceFrames = 0;
    speechFrames = 0;

    sendToParent({ type: 'vosk_status', status: 'listening' });

    scriptNode.onaudioprocess = function(e) {
      if (!listening) return;
      var input = e.inputBuffer.getChannelData(0);
      var sum = 0;
      for (var i = 0; i < input.length; i++) sum += input[i] * input[i];
      var rms = Math.sqrt(sum / input.length);

      if (rms > VAD_THRESHOLD) {
        speechFrames++;
        silenceFrames = 0;
        if (!speaking) {
          speaking = true;
          chunks = [];
          sendToParent({ type: 'vosk_status', status: 'speaking' });
        }
        var buf16 = new Int16Array(input.length);
        for (var i = 0; i < input.length; i++) {
          var s = Math.max(-1, Math.min(1, input[i]));
          buf16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        chunks.push(buf16.buffer);
      } else {
        if (speaking) {
          silenceFrames++;
          if (silenceFrames >= SILENCE_MAX) {
            sendAudio();
            speaking = false;
            silenceFrames = 0;
            speechFrames = 0;
            sendToParent({ type: 'vosk_status', status: 'listening' });
          }
        }
      }
    };
  }).catch(function(err) {
    sendToParent({ type: 'vosk_error', message: err.message });
  });
}

function stopCapture() {
  listening = false;
  speaking = false;
  if (scriptNode) { try { scriptNode.disconnect(); } catch(e) {} scriptNode = null; }
  if (context) { context.close().then(function() { context = null; }); }
  if (stream) { stream.getTracks().forEach(function(t) { t.stop(); }); stream = null; }
  chunks = [];
  sendToParent({ type: 'vosk_status', status: 'stopped' });
}

function sendAudio() {
  if (chunks.length < SPEECH_MIN) { chunks = []; return; }

  var totalLen = 0;
  for (var i = 0; i < chunks.length; i++) totalLen += chunks[i].byteLength;
  var wavBuffer = new ArrayBuffer(44 + totalLen);
  var view = new DataView(wavBuffer);

  function writeString(offset, str) {
    for (var i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  }
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + totalLen, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, totalLen, true);

  var offset = 44;
  for (var i = 0; i < chunks.length; i++) {
    var src = new Uint8Array(chunks[i]);
    for (var j = 0; j < src.length; j++) view.setUint8(offset++, src[j]);
  }
  chunks = [];

  sendToParent({
    type: 'vosk_audio',
    audio: wavBuffer,
    sampleRate: sampleRate
  });
}

window.addEventListener('message', function(e) {
  var d = e.data;
  if (!d || !d.type) return;
  if (d.type === 'vosk_start') startCapture();
  if (d.type === 'vosk_stop') stopCapture();
});
